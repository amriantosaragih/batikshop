/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.batik.model;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author Apria
 */
@Entity
@Table(name = "komentaradmin")
@NamedQueries({
    @NamedQuery(name = "Komentaradmin.findAll", query = "SELECT k FROM Komentaradmin k")})
public class Komentaradmin implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "usernameTujuan")
    private String usernameTujuan;
    @Basic(optional = false)
    @Column(name = "isiKomentar")
    private String isiKomentar;

    public Komentaradmin() {
    }

    public Komentaradmin(Integer id) {
        this.id = id;
    }

    public Komentaradmin(Integer id, String usernameTujuan, String isiKomentar) {
        this.id = id;
        this.usernameTujuan = usernameTujuan;
        this.isiKomentar = isiKomentar;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUsernameTujuan() {
        return usernameTujuan;
    }

    public void setUsernameTujuan(String usernameTujuan) {
        this.usernameTujuan = usernameTujuan;
    }

    public String getIsiKomentar() {
        return isiKomentar;
    }

    public void setIsiKomentar(String isiKomentar) {
        this.isiKomentar = isiKomentar;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Komentaradmin)) {
            return false;
        }
        Komentaradmin other = (Komentaradmin) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "org.batik.model.Komentaradmin[ id=" + id + " ]";
    }
    
}
