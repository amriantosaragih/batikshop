/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.batik.model;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author Apria
 */
@Entity
@Table(name = "pembayaran")
@NamedQueries({
    @NamedQuery(name = "Pembayaran.findAll", query = "SELECT p FROM Pembayaran p")})
public class Pembayaran implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idPembayaran")
    private Integer idPembayaran;
    @Basic(optional = false)
    @Column(name = "bankTujuan")
    private String bankTujuan;
    @Basic(optional = false)
    @Column(name = "tanggalPembayaran")
    private String tanggalPembayaran;
    @Basic(optional = false)
    @Column(name = "metodePembayaran")
    private String metodePembayaran;
    @Basic(optional = false)
    @Column(name = "totalHarga")
    private double totalHarga;

    public Pembayaran() {
    }

    public Pembayaran(Integer idPembayaran) {
        this.idPembayaran = idPembayaran;
    }

    public Pembayaran(Integer idPembayaran, String bankTujuan, String tanggalPembayaran, String metodePembayaran, double totalHarga) {
        this.idPembayaran = idPembayaran;
        this.bankTujuan = bankTujuan;
        this.tanggalPembayaran = tanggalPembayaran;
        this.metodePembayaran = metodePembayaran;
        this.totalHarga = totalHarga;
    }

    public Integer getIdPembayaran() {
        return idPembayaran;
    }

    public void setIdPembayaran(Integer idPembayaran) {
        this.idPembayaran = idPembayaran;
    }

    public String getBankTujuan() {
        return bankTujuan;
    }

    public void setBankTujuan(String bankTujuan) {
        this.bankTujuan = bankTujuan;
    }

    public String getTanggalPembayaran() {
        return tanggalPembayaran;
    }

    public void setTanggalPembayaran(String tanggalPembayaran) {
        this.tanggalPembayaran = tanggalPembayaran;
    }

    public String getMetodePembayaran() {
        return metodePembayaran;
    }

    public void setMetodePembayaran(String metodePembayaran) {
        this.metodePembayaran = metodePembayaran;
    }

    public double getTotalHarga() {
        return totalHarga;
    }

    public void setTotalHarga(double totalHarga) {
        this.totalHarga = totalHarga;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idPembayaran != null ? idPembayaran.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Pembayaran)) {
            return false;
        }
        Pembayaran other = (Pembayaran) object;
        if ((this.idPembayaran == null && other.idPembayaran != null) || (this.idPembayaran != null && !this.idPembayaran.equals(other.idPembayaran))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "org.batik.model.Pembayaran[ idPembayaran=" + idPembayaran + " ]";
    }
    
}
