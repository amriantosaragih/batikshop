/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.batik.model;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author Apria
 */
@Entity
@Table(name = "konfirmasi")
@NamedQueries({
    @NamedQuery(name = "Konfirmasi.findAll", query = "SELECT k FROM Konfirmasi k")})
public class Konfirmasi implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "namaPengirim")
    private String namaPengirim;
    @Column(name = "bankAsal")
    private String bankAsal;
    @Column(name = "bankTujuan")
    private String bankTujuan;
    @Column(name = "noRek")
    private String noRek;
    @Lob
    @Column(name = "gambar")
    private byte[] gambar;

    public Konfirmasi() {
    }

    public Konfirmasi(String namaPengirim) {
        this.namaPengirim = namaPengirim;
    }

    public String getNamaPengirim() {
        return namaPengirim;
    }

    public void setNamaPengirim(String namaPengirim) {
        this.namaPengirim = namaPengirim;
    }

    public String getBankAsal() {
        return bankAsal;
    }

    public void setBankAsal(String bankAsal) {
        this.bankAsal = bankAsal;
    }

    public String getBankTujuan() {
        return bankTujuan;
    }

    public void setBankTujuan(String bankTujuan) {
        this.bankTujuan = bankTujuan;
    }

    public String getNoRek() {
        return noRek;
    }

    public void setNoRek(String noRek) {
        this.noRek = noRek;
    }

    public byte[] getGambar() {
        return gambar;
    }

    public void setGambar(byte[] gambar) {
        this.gambar = gambar;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (namaPengirim != null ? namaPengirim.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Konfirmasi)) {
            return false;
        }
        Konfirmasi other = (Konfirmasi) object;
        if ((this.namaPengirim == null && other.namaPengirim != null) || (this.namaPengirim != null && !this.namaPengirim.equals(other.namaPengirim))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "org.batik.model.Konfirmasi[ namaPengirim=" + namaPengirim + " ]";
    }
    
}
