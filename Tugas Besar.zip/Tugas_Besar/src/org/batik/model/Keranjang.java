/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.batik.model;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author Apria
 */
@Entity
@Table(name = "keranjang")
@NamedQueries({
    @NamedQuery(name = "Keranjang.findAll", query = "SELECT k FROM Keranjang k")})
public class Keranjang implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "usernamePembeli")
    private String usernamePembeli;
    @Column(name = "usernameToko")
    private String usernameToko;
    @Basic(optional = false)
    @Column(name = "idBarang")
    private String idBarang;
    @Basic(optional = false)
    @Column(name = "jumlah")
    private int jumlah;
    @Basic(optional = false)
    @Column(name = "totalHarga")
    private double totalHarga;

    public Keranjang() {
    }

    public Keranjang(String usernamePembeli) {
        this.usernamePembeli = usernamePembeli;
    }

    public Keranjang(String usernamePembeli, String usernameToko, String idBarang, int jumlah, double totalHarga) {
        this.usernamePembeli = usernamePembeli;
        this.usernameToko = usernameToko;
        this.idBarang = idBarang;
        this.jumlah = jumlah;
        this.totalHarga = totalHarga;
    }

    public String getUsernamePembeli() {
        return usernamePembeli;
    }

    public void setUsernamePembeli(String usernamePembeli) {
        this.usernamePembeli = usernamePembeli;
    }

    public String getUsernameToko() {
        return usernameToko;
    }

    public void setUsernameToko(String usernameToko) {
        this.usernameToko = usernameToko;
    }

    public String getIdBarang() {
        return idBarang;
    }

    public void setIdBarang(String idBarang) {
        this.idBarang = idBarang;
    }

    public int getJumlah() {
        return jumlah;
    }

    public void setJumlah(int jumlah) {
        this.jumlah = jumlah;
    }

    public double getTotalHarga() {
        return totalHarga;
    }

    public void setTotalHarga(double totalHarga) {
        this.totalHarga = totalHarga;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (usernamePembeli != null ? usernamePembeli.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Keranjang)) {
            return false;
        }
        Keranjang other = (Keranjang) object;
        if ((this.usernamePembeli == null && other.usernamePembeli != null) || (this.usernamePembeli != null && !this.usernamePembeli.equals(other.usernamePembeli))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "org.batik.model.Keranjang[ usernamePembeli=" + usernamePembeli + " ]";
    }
    
}
