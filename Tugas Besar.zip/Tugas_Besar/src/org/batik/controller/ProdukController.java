/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.batik.controller;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Rectangle2D;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import org.batik.dao.AkunDao;
import org.batik.dao.ProdukDao;
import org.batik.dao.TokoDao;
import org.batik.impl.AkunImplHibernate;
import org.batik.impl.ProdukImplHibernate;
import org.batik.impl.TokoImplHibernate;
import org.batik.model.Akun;
import org.batik.model.Produk;
import org.batik.model.Toko;

/**
 * FXML Controller class
 *
 * @author Amrianto Saragih
 */
public class ProdukController implements Initializable {
    
    @FXML
    private ComboBox pilihanCB;
    ObservableList<String>pilihan=FXCollections.observableArrayList("Baju", "Gaun", "Aksesoris", "Rok");    
    @FXML
    private Label imageL1;
    @FXML
    private Label imageL2;
    @FXML
    private Label imageL3;   
    @FXML
    private Label imageL4;
    @FXML
    private Label imageL5;
    @FXML
    private Label imageL6;
    @FXML
    private Label imageL7;
    @FXML
    private Label imageL8;   
    @FXML
    private Label imageL9;   
    @FXML
    private ImageView image;    
    @FXML
    private ImageView image2;
    @FXML
    private ImageView image3;
    @FXML
    private ImageView image4;
    @FXML
    private ImageView image5;
    @FXML
    private ImageView image6;
    @FXML
    private ImageView image7;
    @FXML
    private ImageView image8; 
    @FXML
    private ImageView image9; 
    @FXML
    private Button lihatButton1;
    @FXML
    private Button lihatButton2;
    @FXML
    private Button lihatButton3;
    @FXML
    private Button lihatButton4;
    @FXML
    private Button lihatButton5;
    @FXML
    private Button lihatButton6;
    @FXML
    private Button lihatButton7;
    @FXML
    private Button lihatButton8;
    @FXML
    private Button lihatButton9;
                        
    @FXML
    private Label nama;
    private AkunDao akunDao;
    private TokoDao tokoDao;
    private ProdukDao produkDao;
    private TampilanController tampil;
    
    public ProdukController() 
    {
        akunDao = AkunImplHibernate.getAkunImpl();
        tokoDao = TokoImplHibernate.getTokoImpl();
        produkDao = ProdukImplHibernate.getProdukImpl();
        tampil = new TampilanController();
    }
    
    public void loadData(){
        List<Akun> listAkun = akunDao.getAllAkun();
        List<Toko> listToko = tokoDao.getAllToko();
        List<Produk> listProduk = produkDao.getAllProduk();
        try{
        for(Akun akun : listAkun){
          for(Toko toko : listToko){
           if(akun.getPenanda()==1&&akun.getUsername().equals(toko.getUsername())){
               nama.setText("Hai "+toko.getNamaToko()); 
            for(int i=0; i<listProduk.size();i++){                                            
               if(listProduk.get(i).getUsernameToko().equals(toko.getUsername())){
                   produkDao.getDataProduk(listProduk.get(i).getId());
                   if(i==0){
                    imageL1.setText(listProduk.get(i).getNama());
                    image.setImage(new Image("file:gambar.jpg"));
                    lihatButton1.setVisible(true);
                   }else if(i==1){
                    imageL2.setText(listProduk.get(i).getNama());
                    image2.setImage(new Image("file:gambar.jpg"));
                    lihatButton2.setVisible(true);
                   }else if(i==2){
                    imageL3.setText(listProduk.get(i).getNama());
                    image3.setImage(new Image("file:gambar.jpg")); 
                    lihatButton3.setVisible(true);
                   }else if(i==3){
                    imageL4.setText(listProduk.get(i).getNama());
                    image4.setImage(new Image("file:gambar.jpg"));
                    lihatButton4.setVisible(true);
                   }else if(i==4){
                    imageL5.setText(listProduk.get(i).getNama());
                    image5.setImage(new Image("file:gambar.jpg"));
                    lihatButton5.setVisible(true);
                   }else if(i==5){
                    imageL6.setText(listProduk.get(i).getNama());
                    image6.setImage(new Image("file:gambar.jpg")); 
                    lihatButton6.setVisible(true);
                   }else if(i==6){
                    imageL7.setText(listProduk.get(i).getNama());
                    image7.setImage(new Image("file:gambar.jpg"));
                    lihatButton7.setVisible(true);
                   }else if(i==7){
                    imageL8.setText(listProduk.get(i).getNama());
                    image8.setImage(new Image("file:gambar.jpg")); 
                    lihatButton8.setVisible(true);
                   }else if(i==8){
                    imageL9.setText(listProduk.get(i).getNama());
                    image9.setImage(new Image("file:gambar.jpg"));
                    lihatButton9.setVisible(true);
                   }
                }
              }
            }
          }
        }
        }catch(NullPointerException ne){
            System.out.println(""+ne.getMessage());
        }
    }
    
    @FXML
    public void viewButton1(ActionEvent event) throws IOException{
        List<Produk> listProduk = produkDao.getAllProduk();
        produkDao.setIdBarang(listProduk.get(0).getId());
        ((Node)(event.getSource())).getScene().getWindow().hide();        
        tampil.Tampil("LihatProduk"); 
    }
    @FXML
    public void viewButton2(ActionEvent event) throws IOException{
        List<Produk> listProduk = produkDao.getAllProduk();
        produkDao.setIdBarang(listProduk.get(1).getId()); 
        ((Node)(event.getSource())).getScene().getWindow().hide();           
        tampil.Tampil("LihatProduk");           
    }   
    @FXML
    public void viewButton3(ActionEvent event) throws IOException{
        List<Produk> listProduk = produkDao.getAllProduk();
        produkDao.setIdBarang(listProduk.get(2).getId());
        ((Node)(event.getSource())).getScene().getWindow().hide();        
        tampil.Tampil("LihatProduk");           
    }    
    @FXML
    public void viewButton4(ActionEvent event) throws IOException{
        List<Produk> listProduk = produkDao.getAllProduk();
        produkDao.setIdBarang(listProduk.get(3).getId()); 
        ((Node)(event.getSource())).getScene().getWindow().hide();           
           tampil.Tampil("LihatProduk");           
    }
    @FXML
    public void viewButton5(ActionEvent event) throws IOException{
        List<Produk> listProduk = produkDao.getAllProduk();
        produkDao.setIdBarang(listProduk.get(4).getId());         
        ((Node)(event.getSource())).getScene().getWindow().hide();
        tampil.Tampil("LihatProduk");           
    }    
    @FXML
    public void viewButton6(ActionEvent event) throws IOException{
        List<Produk> listProduk = produkDao.getAllProduk();
        produkDao.setIdBarang(listProduk.get(5).getId());        
        ((Node)(event.getSource())).getScene().getWindow().hide(); 
        tampil.Tampil("LihatProduk");           
    }    
    @FXML
    public void viewButton7(ActionEvent event) throws IOException{
        List<Produk> listProduk = produkDao.getAllProduk();
        produkDao.setIdBarang(listProduk.get(6).getId()); 
        ((Node)(event.getSource())).getScene().getWindow().hide();           
        tampil.Tampil("LihatProduk");           
    }    
    @FXML
    public void viewButton8(ActionEvent event) throws IOException{
        List<Produk> listProduk = produkDao.getAllProduk();
        tampil.Tampil("LihatProduk");        
        ((Node)(event.getSource())).getScene().getWindow().hide();
        produkDao.setIdBarang(listProduk.get(7).getId()); 
    }   
    @FXML
    public void viewButton9(ActionEvent event) throws IOException{
        List<Produk> listProduk = produkDao.getAllProduk();
        produkDao.setIdBarang(listProduk.get(8).getId());        
        ((Node)(event.getSource())).getScene().getWindow().hide(); 
        tampil.Tampil("LihatProduk");           
    }    
    @FXML
    public void tambahButton(ActionEvent event) throws IOException{
        ((Node)(event.getSource())).getScene().getWindow().hide();
        tampil.Tampil("TambahBarang");
    }
    
    @FXML
    public void profilButton(ActionEvent event) throws IOException{
        ((Node)(event.getSource())).getScene().getWindow().hide();
        tampil.Tampil("ProfilToko");
    }
    
    @FXML
    public void produkButton(ActionEvent event) throws IOException{
       ((Node)(event.getSource())).getScene().getWindow().hide();
        tampil.Tampil("Produk");        
    }
    
    @FXML
    public void berandaButton(ActionEvent event) throws IOException{
        ((Node)(event.getSource())).getScene().getWindow().hide();
        tampil.Tampil("BerandaToko");
    }
    
    @FXML
    public void keluarButton(ActionEvent event) throws IOException{
        List<Akun> listAkun = akunDao.getAllAkun();
        List<Toko> listToko = tokoDao.getAllToko();
        for(Akun akun : listAkun){
            for(Toko toko : listToko){
            if(akun.getPenanda()==1 && akun.getUsername().equals(toko.getUsername())){
                Akun akun1 = new Akun(akun.getUsername(), akun.getPassword(), akun.getNama(), akun.getStatus(), 0);
                akunDao.updateAkun(akun1);
                ((Node)(event.getSource())).getScene().getWindow().hide();
                tampil.Tampil("Login");                
            }
            }
        }
    }
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        loadData();
    }    
    
}
