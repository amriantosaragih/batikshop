
package org.batik.controller;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import org.batik.dao.AkunDao;
import org.batik.dao.KeranjangDao;
import org.batik.dao.PembeliDao;
import org.batik.dao.ProdukDao;
import org.batik.dao.TokoDao;
import org.batik.impl.AkunImplHibernate;
import org.batik.impl.KeranjangImplHibernate;
import org.batik.impl.PembeliImplHibernate;
import org.batik.impl.ProdukImplHibernate;
import org.batik.impl.TokoImplHibernate;
import org.batik.model.Akun;
import org.batik.model.Keranjang;
import org.batik.model.Pembeli;
import org.batik.model.Produk;
import org.batik.model.Toko;

/**
 * FXML Controller class
 *
 * @author Amrianto Saragih
 */
public class KeranjangController implements Initializable {

    @FXML
    private Label userLabel;
    @FXML
    private Label imageL1;
    @FXML
    private Label imageL11;
    @FXML
    private Label imageL2;
    @FXML
    private Label imageL21;
    @FXML
    private ImageView image1;
    @FXML
    private ImageView image2;   
    @FXML
    private Label imageL3;
    @FXML
    private Label imageL31;
    @FXML
    private Label imageL4;
    @FXML
    private Label imageL41;
    @FXML
    private ImageView image3;
    @FXML
    private ImageView image4; 
        @FXML
    private Label imageL5;
    @FXML
    private Label imageL51;
    @FXML
    private Label imageL6;
    @FXML
    private Label imageL61;
    @FXML
    private ImageView image5;
    @FXML
    private ImageView image6; 
    @FXML
    private Button tambah;
    @FXML
    private Button kurang;
    @FXML
    private Button jumlah;
    @FXML
    private Button tambah1;
    @FXML
    private Button kurang1;
    @FXML
    private Button jumlah1; 
    @FXML
    private Button tambah2;
    @FXML
    private Button kurang2;
    @FXML
    private Button jumlah2;
    @FXML
    private Button tambah3;
    @FXML
    private Button kurang3;
    @FXML
    private Button jumlah3; 
    @FXML
    private Button tambah4;
    @FXML
    private Button kurang4;
    @FXML
    private Button jumlah4; 
    @FXML
    private Button tambah5;
    @FXML
    private Button kurang5;
    @FXML
    private Button jumlah5;    
    @FXML
    private Button next;
    @FXML
    private Label kosong;
    @FXML
    private Button lanjutBayar;
    @FXML
    private Button lanjutBelanja;
    
    private TampilanController tampil;
    private AkunDao akunDao;
    private ProdukDao produkDao;
    private TokoDao tokoDao;
    private KeranjangDao keranjangDao;
    private PembeliDao pembeliDao;
  
    public KeranjangController() 
    {
      akunDao = AkunImplHibernate.getAkunImpl();
      produkDao = ProdukImplHibernate.getProdukImpl();
      tokoDao = TokoImplHibernate.getTokoImpl();
      keranjangDao = KeranjangImplHibernate.getkeranjangImpl();
      pembeliDao = PembeliImplHibernate.getPembeliImpl();
      tampil = new TampilanController();
    }
    
    public void loadData(){
        List<Akun> listAkun = akunDao.getAllAkun();
        List<Produk> listProduk = produkDao.getAllProduk();
        List<Keranjang> listKeranjang = keranjangDao.getAllKeranjang();
        List<Toko> listToko = tokoDao.getAllToko();
        List<Pembeli> listPembeli = pembeliDao.getAllPembeli();
        
        for(Akun  akun : listAkun){
            for(Pembeli pembeli : listPembeli){
               if(akun.getPenanda()==1 && pembeli.getUsername().equals(akun.getUsername())){
                   userLabel.setText("Hai , "+pembeli.getNama());
               }
            }
          if(listKeranjang.size()==0){
              kosong.setVisible(true);
          }  
        for(int i=0; i<listKeranjang.size(); i++){
                if(akun.getUsername().equals(listKeranjang.get(i).getUsernamePembeli()) && akun.getPenanda()==1){
                    for(Produk produk : listProduk){
                        if(produk.getId().equals(listKeranjang.get(i).getIdBarang())){
                            if(i==0){
                                produkDao.getDataProduk(produk.getUsernameToko());
                                produkDao.getFoto(produk.getUsernameToko());
                                imageL1.setText(produk.getNama());
                                imageL11.setText("Harga : "+produk.getHarga());
                                image1.setImage(new Image("file:gambar.jpg"));
                                tambah.setVisible(true);
                                kurang.setVisible(true);
                                jumlah.setVisible(true);
                                jumlah.setText("1");
                                lanjutBayar.setVisible(true);
                                lanjutBelanja.setVisible(true);
                            }else if(i==1){
                                produkDao.getDataProduk(produk.getUsernameToko());
                                produkDao.getFoto(produk.getUsernameToko());
                                imageL2.setText(produk.getNama());
                                imageL21.setText("Harga : "+produk.getHarga());
                                image2.setImage(new Image("file:gambar.jpg")); 
                                tambah1.setVisible(true);
                                kurang1.setVisible(true);
                                jumlah1.setVisible(true);
                                jumlah1.setText("1");
                            }else if(i==2){
                                produkDao.getDataProduk(produk.getUsernameToko());
                                produkDao.getFoto(produk.getUsernameToko());
                                imageL3.setText(produk.getNama());
                                imageL31.setText("Harga : "+produk.getHarga());
                                image3.setImage(new Image("file:gambar.jpg"));   
                                tambah2.setVisible(true);
                                kurang2.setVisible(true);
                                jumlah2.setVisible(true);
                                jumlah2.setText("1");
                            }else if(i==3){
                                produkDao.getDataProduk(produk.getUsernameToko());
                                produkDao.getFoto(produk.getUsernameToko());
                                imageL4.setText(produk.getNama());
                                imageL41.setText("Harga : "+produk.getHarga());
                                image4.setImage(new Image("file:gambar.jpg")); 
                                tambah3.setVisible(true);
                                kurang3.setVisible(true);
                                jumlah3.setVisible(true);
                                jumlah3.setText("1");
                            }else if(i==4){
                                produkDao.getDataProduk(produk.getUsernameToko());
                                produkDao.getFoto(produk.getUsernameToko());
                                imageL5.setText(produk.getNama());
                                imageL51.setText("Harga : "+produk.getHarga());
                                image5.setImage(new Image("file:gambar.jpg"));  
                                tambah4.setVisible(true);
                                kurang4.setVisible(true);
                                jumlah4.setVisible(true);
                                jumlah4.setText("1");
                            }else if(i==5){
                                produkDao.getDataProduk(produk.getUsernameToko());
                                produkDao.getFoto(produk.getUsernameToko());
                                imageL6.setText(produk.getNama());
                                imageL61.setText("Harga : "+produk.getHarga());
                                image6.setImage(new Image("file:gambar.jpg")); 
                                tambah5.setVisible(true);
                                kurang5.setVisible(true);
                                jumlah5.setVisible(true);
                                jumlah5.setText("1");
                            }else if(i>5){
                                next.setVisible(true);
                            }
                        }
                    }
                }
            }
        }
     }
    
    @FXML
    public void nextButton(ActionEvent event) throws IOException{
        ((Node)(event.getSource())).getScene().getWindow().hide();
        tampil.Tampil("");
    }
    
    @FXML
    public void lanjutBayarButton(ActionEvent event) throws IOException{
        ((Node)(event.getSource())).getScene().getWindow().hide();
        tampil.Tampil("");
    }
    
    @FXML
    public void lanjutBelanjaButton(ActionEvent event) throws IOException{
        ((Node)(event.getSource())).getScene().getWindow().hide();
        tampil.Tampil("");
    }
    @FXML
    public void tambahButton1(ActionEvent event){
        int jumlahBarang = Integer.parseInt(jumlah.getText());
        jumlah.setText(""+(jumlahBarang+1));
    }
    
    @FXML
    public void kurangButton1(ActionEvent event){
        int jumlahBarang = Integer.parseInt(jumlah.getText());
        jumlah.setText(""+(jumlahBarang-1));        
    }

    @FXML
    public void tambahButton2(ActionEvent event){
        int jumlahBarang = Integer.parseInt(jumlah1.getText());
        jumlah1.setText(""+(jumlahBarang+1));        
    }
    
    @FXML
    public void kurangButton2(ActionEvent event){
        int jumlahBarang = Integer.parseInt(jumlah1.getText());
        jumlah1.setText(""+(jumlahBarang-1));        
    }    
    @FXML
    public void tambahButton3(ActionEvent event){
        int jumlahBarang = Integer.parseInt(jumlah2.getText());
        jumlah2.setText(""+(jumlahBarang+1));        
    }
    
    @FXML
    public void kurangButton3(ActionEvent event){
        int jumlahBarang = Integer.parseInt(jumlah2.getText());
        jumlah2.setText(""+(jumlahBarang-1));        
    }    
    @FXML
    public void tambahButton4(ActionEvent event){
        int jumlahBarang = Integer.parseInt(jumlah3.getText());
        jumlah3.setText(""+(jumlahBarang+1));        
    }
    
    @FXML
    public void kurangButton4(ActionEvent event){
        int jumlahBarang = Integer.parseInt(jumlah3.getText());
        jumlah3.setText(""+(jumlahBarang-1));        
    }
    @FXML
    public void tambahButton5(ActionEvent event){
        int jumlahBarang = Integer.parseInt(jumlah4.getText());
        jumlah4.setText(""+(jumlahBarang+1));        
    }
    
    @FXML
    public void kurangButton5(ActionEvent event){
        int jumlahBarang = Integer.parseInt(jumlah4.getText());
        jumlah4.setText(""+(jumlahBarang-1));        
    } 
    @FXML
    public void tambahButton6(ActionEvent event){
        int jumlahBarang = Integer.parseInt(jumlah5.getText());
        jumlah5.setText(""+(jumlahBarang+1));        
    }
    
    @FXML
    public void kurangButton6(ActionEvent event){
        int jumlahBarang = Integer.parseInt(jumlah5.getText());
        jumlah5.setText(""+(jumlahBarang-1));        
    }    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        loadData();
    }    
    
}
