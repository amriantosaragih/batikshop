/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.batik.controller;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import org.batik.dao.AkunDao;
import org.batik.dao.TokoDao;
import org.batik.impl.AkunImplHibernate;
import org.batik.impl.TokoImplHibernate;
import org.batik.model.Akun;
import org.batik.model.Toko;

/**
 * FXML Controller class
 *
 * @author Amrianto Saragih
 */
public class ProfilTokoController implements Initializable {

    @FXML
    private Label namaL;
    @FXML
    private Label alamatL;
    @FXML
    private Label noRekBankL;
    @FXML
    private Label userL;
    @FXML
    private TextArea deskripsiTA;
    @FXML
    private Label noTelpL;
    @FXML
    private ImageView foto;
    private AkunDao akunDao;
    private TokoDao tokoDao;
    private TampilanController tampil;
    
    public ProfilTokoController()
    {
        akunDao = AkunImplHibernate.getAkunImpl();
        tokoDao = TokoImplHibernate.getTokoImpl();
        tampil = new TampilanController();
    }
    
    public void loadData(){
        List<Akun> listAkun = akunDao.getAllAkun();
        List<Toko> listToko = tokoDao.getAllToko();
        try{
            for(Akun akun : listAkun){
                for(Toko toko : listToko){
                if(akun.getPenanda()==1 && akun.getUsername().equals(toko.getUsername())){
                    tokoDao.getDataToko(toko.getUsername());
                    userL.setText("Hai , "+toko.getNamaToko()+"");
                    namaL.setText(toko.getNamaToko());
                    alamatL.setText(toko.getAlamat());
                    noTelpL.setText(toko.getNoTelp());
                    noRekBankL.setText(toko.getNoRekBank());
                    deskripsiTA.setText(toko.getDeskripsiToko());
                    foto.setImage(new Image("file:foto.jpg"));
                }
              }
            }
        }catch(NullPointerException ne){
            System.out.println(""+ne.getMessage());
        }
    }
    
    @FXML
    public void editProfilButton(ActionEvent event) throws IOException{
        ((Node) (event.getSource())).getScene().getWindow().hide();
        tampil.Tampil("UpdateProfil");
    }
    
    @FXML
    public void profilButton(ActionEvent event) throws IOException{
        ((Node)(event.getSource())).getScene().getWindow().hide();
        tampil.Tampil("ProfilToko");
    }
    
    @FXML
    public void produkButton(ActionEvent event) throws IOException{
       ((Node)(event.getSource())).getScene().getWindow().hide();
        tampil.Tampil("Produk");
    }
    
    @FXML
    public void berandaButton(ActionEvent event) throws IOException{
        ((Node)(event.getSource())).getScene().getWindow().hide();
        tampil.Tampil("BerandaToko");
    }
    
    @FXML
    public void keluarButton(ActionEvent event) throws IOException{
        List<Akun> listAkun = akunDao.getAllAkun();
        for(Akun akun : listAkun){
            if(akun.getPenanda()==1){
                Akun akun1 = new Akun(akun.getUsername(), akun.getPassword(), akun.getNama(), akun.getStatus(), 0);
                akunDao.updateAkun(akun1);
                ((Node)(event.getSource())).getScene().getWindow().hide();
                tampil.Tampil("Login");                
            }
        }
    }
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        loadData();
    }    
    
}
