/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.batik.controller;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollBar;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javax.swing.JOptionPane;
import org.batik.dao.AkunDao;
import org.batik.dao.KeranjangDao;
import org.batik.dao.PembeliDao;
import org.batik.dao.ProdukDao;
import org.batik.impl.AkunImplHibernate;
import org.batik.impl.KeranjangImplHibernate;
import org.batik.impl.PembeliImplHibernate;
import org.batik.impl.ProdukImplHibernate;
import org.batik.model.Akun;
import org.batik.model.Keranjang;
import org.batik.model.Pembeli;
import org.batik.model.Produk;


/**
 *
 * @author Amrianto Saragih
 */
public class BerandaPembeliController implements Initializable{
    
    ObservableList<String>pilihan=FXCollections.observableArrayList("Baju", "Rok", "Gaun", "Aksesoris"); 
    private ComboBox pilihanCB;
    private AkunDao akunDao;
    private PembeliDao pembeliDao;
    private ProdukDao produkDao;
    private KeranjangDao keranjangDao;
    private TampilanController tampil;
    @FXML
    private TextArea deskripsi;
    @FXML
    private Label pembeliLabel;
    @FXML
    private ScrollBar scrollBar;
    @FXML
    private AnchorPane pane;
    @FXML
    private ImageView image1;
    @FXML
    private ImageView image2;
    @FXML
    private ImageView image3; 
    @FXML
    private ImageView image4;
    @FXML
    private ImageView image5; 
    @FXML
    private ImageView image6;
    @FXML
    private ImageView image7;
    @FXML
    private ImageView image8;
    @FXML
    private ImageView image9;
    @FXML
    private ImageView image10;
    @FXML
    private ImageView image11;
    @FXML
    private ImageView image12;
    @FXML
    private Button button1;
    @FXML
    private Button button2;
    @FXML
    private Button button3;
    @FXML
    private Button button4;
    @FXML
    private Button button5;
    @FXML
    private Button button6;
    @FXML
    private Button button7;
    @FXML
    private Button button8;
    @FXML
    private Button button9;
    @FXML
    private Button button10;
    @FXML
    private Button button11;
    @FXML
    private Button button12;
    @FXML
    private TextArea label1;
    @FXML
    private TextArea label2;
    @FXML
    private TextArea label3;
    @FXML
    private TextArea label4;
    @FXML
    private TextArea label5;
    @FXML
    private TextArea label6;
    @FXML
    private TextArea label7;
    @FXML
    private TextArea label8;
    @FXML
    private TextArea label9;
    @FXML
    private TextArea label10;
    @FXML
    private TextArea label11;
    @FXML
    private TextArea label12;  
    private String idBarang1;
    private String idBarang2;
    private String idBarang3;
    private String idBarang4;
    private String idBarang5;
    private String idBarang6;
    private String idBarang7;
    private String idBarang8;
    private String idBarang9;
    private String idBarang10;
    private String idBarang11;
    private String idBarang12; 
    private String username1;
    private String username2;
    private String username3;
    private String username4;
    private String username5;
    private String username6;
    private String username7;
    private String username8;
    private String username9;
    private String username10;
    private String username11;
    private String username12;
    private double harga1=0;
    private double harga2=0;
    private double harga3=0;
    private double harga4=0;
    private double harga5=0;
    private double harga6=0;    
    private double harga7=0;
    private double harga8=0;
    private double harga9=0;
    private double harga10=0;
    private double harga11=0;
    private double harga12=0;  
    private String usernamePembeli=null;

    public BerandaPembeliController() 
    {
        akunDao = AkunImplHibernate.getAkunImpl();
        pembeliDao = PembeliImplHibernate.getPembeliImpl();
        tampil = new TampilanController();
        produkDao = ProdukImplHibernate.getProdukImpl();
        keranjangDao = KeranjangImplHibernate.getkeranjangImpl();
        pilihanCB = new ComboBox(pilihan);
    }
   
    public void loadData()
    {
        pilihanCB.setItems(pilihan);
        List<Akun> listAkun = akunDao.getAllAkun();
        List<Pembeli> listPembeli = pembeliDao.getAllPembeli();
        try{
            for(Akun akun : listAkun){
                for(Pembeli pembeli : listPembeli){
                    if(akun.getPenanda()==1 && akun.getUsername().equals(pembeli.getUsername())){
                        usernamePembeli=akun.getNama();
                        pembeliLabel.setText("Hai "+akun.getNama());                        
                    }
                }
            }
        }catch(NullPointerException ne){
            System.out.println(""+ne.getMessage());
        }
        scrollBar.valueProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> ov, Number t, Number t1) {
                pane.setLayoutY(-(t.doubleValue()*4));
            }
        });
    }
    public void loadData2(){
        List<Produk> listProduk = produkDao.getAllProduk();
        try{
        for(int i=0 ; i<listProduk.size(); i++){
            produkDao.getDataProduk(listProduk.get(i).getId());
            if(i==0){
                button1.setVisible(true);
                label1.setText("Nama Baju : "+listProduk.get(i).getNama()+"\nHarga         : "+listProduk.get(i).getHarga());
                label1.setVisible(true);
                idBarang1=listProduk.get(i).getId();
                username1= listProduk.get(i).getUsernameToko();
                harga1 = listProduk.get(i).getHarga();
                image1.setImage(new Image("file:gambar.jpg"));
            }else if(i==1){
                button2.setVisible(true);
                label2.setText("Nama Baju : "+listProduk.get(i).getNama()+"\nHarga         : "+listProduk.get(i).getHarga());
                label2.setVisible(true);
                idBarang2=listProduk.get(i).getId();
                username2= listProduk.get(i).getUsernameToko();
                harga2 = listProduk.get(i).getHarga();
                image2.setImage(new Image("file:gambar.jpg"));                
            }else if(i==2){
                button3.setVisible(true);
                label3.setText("Nama Baju : "+listProduk.get(i).getNama()+"\nHarga         : "+listProduk.get(i).getHarga());
                label3.setVisible(true);
                idBarang3=listProduk.get(i).getId();
                username3= listProduk.get(i).getUsernameToko();
                harga3 = listProduk.get(i).getHarga();
                image3.setImage(new Image("file:gambar.jpg"));                
            }else if(i==3){
                button4.setVisible(true);
                label4.setText("Nama Baju : "+listProduk.get(i).getNama()+"\nHarga         : "+listProduk.get(i).getHarga());
                label4.setVisible(true); 
                idBarang4=listProduk.get(i).getId();
                username4= listProduk.get(i).getUsernameToko();
                harga4 = listProduk.get(i).getHarga();
                image4.setImage(new Image("file:gambar.jpg"));                
            }else if(i==4){
                button5.setVisible(true);
                label5.setText("Nama Baju : "+listProduk.get(i).getNama()+"\nHarga         : "+listProduk.get(i).getHarga());
                label5.setVisible(true);
                idBarang5=listProduk.get(i).getId();
                username5= listProduk.get(i).getUsernameToko();
                harga5 = listProduk.get(i).getHarga();
                image5.setImage(new Image("file:gambar.jpg"));                
            }else if(i==5){
                button6.setVisible(true);
                label6.setText("Nama Baju : "+listProduk.get(i).getNama()+"\nHarga         : "+listProduk.get(i).getHarga());
                label6.setVisible(true);
                idBarang6=listProduk.get(i).getId();
                username6= listProduk.get(i).getUsernameToko();
                harga6 = listProduk.get(i).getHarga();
                image6.setImage(new Image("file:gambar.jpg")); 
            }else if(i==6){
                button7.setVisible(true);
                label7.setText("Nama Baju : "+listProduk.get(i).getNama()+"\nHarga         : "+listProduk.get(i).getHarga());
                label7.setVisible(true);
                idBarang7=listProduk.get(i).getId();
                username7= listProduk.get(i).getUsernameToko();
                harga7 = listProduk.get(i).getHarga();
                image7.setImage(new Image("file:gambar.jpg")); 
            }else if(i==7){
                button8.setVisible(true);
                label8.setText("Nama Baju : "+listProduk.get(i).getNama()+"\nHarga         : "+listProduk.get(i).getHarga());
                label8.setVisible(true);
                idBarang8=listProduk.get(i).getId();
                username8= listProduk.get(i).getUsernameToko();
                harga8 = listProduk.get(i).getHarga();
                image8.setImage(new Image("file:gambar.jpg"));  
            }else if(i==8){
                button9.setVisible(true);
                label9.setText("Nama Baju : "+listProduk.get(i).getNama()+"\nHarga         : "+listProduk.get(i).getHarga());
                label9.setVisible(true);
                idBarang9=listProduk.get(i).getId();
                username9= listProduk.get(i).getUsernameToko();
                harga9 = listProduk.get(i).getHarga();
                image9.setImage(new Image("file:gambar.jpg")); 
            }else if(i==9){
                button10.setVisible(true);
                label10.setText("Nama Baju : "+listProduk.get(i).getNama()+"\nHarga        : "+listProduk.get(i).getHarga());
                label10.setVisible(true);
                idBarang10=listProduk.get(i).getId();
                username10= listProduk.get(i).getUsernameToko();
                harga10 = listProduk.get(i).getHarga();
                image10.setImage(new Image("file:gambar.jpg")); 
            }else if(i==10){
                button11.setVisible(true);
                label11.setText("Nama Baju : "+listProduk.get(i).getNama()+"\nHarga        : "+listProduk.get(i).getHarga());
                label11.setVisible(true);
                idBarang11=listProduk.get(i).getId();
                username11= listProduk.get(i).getUsernameToko();
                harga11 = listProduk.get(i).getHarga();
                image11.setImage(new Image("file:gambar.jpg"));
            }else if(i==11){
                button12.setVisible(true);
                label12.setText("Nama Baju : "+listProduk.get(i).getNama()+"\nHarga        : "+listProduk.get(i).getHarga());
                label12.setVisible(true);
                idBarang12=listProduk.get(i).getId();
                username12= listProduk.get(i).getUsernameToko();
                harga12 = listProduk.get(i).getHarga();
                image12.setImage(new Image("file:gambar.jpg"));
            }
        }
        }catch(NullPointerException ne){
            
        }
    }
    
    public void beliButton1(ActionEvent event) throws IOException{
        Keranjang keranjang = new Keranjang(usernamePembeli, username1, idBarang1, 1, harga1);
        String message = "Produk dengan "+label1.getText()+" \nTelah di tambahkan ke list"+"\n klik button keranjang untuk melihat semua pesanan.";
        JOptionPane.showMessageDialog(null, message);
    }
    public void beliButton2(ActionEvent event) throws IOException{
        Keranjang keranjang = new Keranjang(usernamePembeli, username2, idBarang2, 1, harga12);
        String message = "Produk dengan "+label2.getText()+" \nTelah di tambahkan ke list"+"\n klik button keranjang untuk melihat semua pesanan.";
        JOptionPane.showMessageDialog(null, message);
    }    
    public void beliButton3(ActionEvent event) throws IOException{
        Keranjang keranjang = new Keranjang(usernamePembeli, username3, idBarang3, 1, harga3);
        String message = "Produk dengan "+label3.getText()+" \nTelah di tambahkan ke list"+"\n klik button keranjang untuk melihat semua pesanan.";
        JOptionPane.showMessageDialog(null, message);
    }    
    public void beliButton4(ActionEvent event) throws IOException{
        Keranjang keranjang = new Keranjang(usernamePembeli, username4, idBarang4, 1, harga4);
        String message = "Produk dengan "+label4.getText()+" \nTelah di tambahkan ke list"+"\n klik button keranjang untuk melihat semua pesanan.";
        JOptionPane.showMessageDialog(null, message);
    }    
    public void beliButton5(ActionEvent event) throws IOException{
        Keranjang keranjang = new Keranjang(usernamePembeli, username5, idBarang5, 1, harga5);
        String message = "Produk dengan "+label5.getText()+" \nTelah di tambahkan ke list"+"\n klik button keranjang untuk melihat semua pesanan.";
        JOptionPane.showMessageDialog(null, message);
    }    
    public void beliButton6(ActionEvent event) throws IOException{
        Keranjang keranjang = new Keranjang(usernamePembeli, username6, idBarang6, 1, harga6);
        String message = "Produk dengan "+label6.getText()+" \nTelah di tambahkan ke list"+"\n klik button keranjang untuk melihat semua pesanan.";
        JOptionPane.showMessageDialog(null, message);
    }    
    public void beliButton7(ActionEvent event) throws IOException{
        Keranjang keranjang = new Keranjang(usernamePembeli, username7, idBarang7, 1, harga7);
        String message = "Produk dengan "+label7.getText()+" \nTelah di tambahkan ke list"+"\n klik button keranjang untuk melihat semua pesanan.";
        JOptionPane.showMessageDialog(null, message);
    }    
    public void beliButton8(ActionEvent event) throws IOException{
        Keranjang keranjang = new Keranjang(usernamePembeli, username8, idBarang8, 1, harga8);
        String message = "Produk dengan "+label8.getText()+" \nTelah di tambahkan ke list"+"\n klik button keranjang untuk melihat semua pesanan.";
        JOptionPane.showMessageDialog(null, message);
    }    
    public void beliButton9(ActionEvent event) throws IOException{
        Keranjang keranjang = new Keranjang(usernamePembeli, username9, idBarang9, 1, harga9);
        String message = "Produk dengan "+label9.getText()+" \nTelah di tambahkan ke list"+"\n klik button keranjang untuk melihat semua pesanan.";
        JOptionPane.showMessageDialog(null, message);
    }    
    public void beliButton10(ActionEvent event) throws IOException{
        Keranjang keranjang = new Keranjang(usernamePembeli, username10, idBarang10, 1, harga10);
        String message = "Produk dengan "+label10.getText()+" \nTelah di tambahkan ke list"+"\n klik button keranjang untuk melihat semua pesanan.";
        JOptionPane.showMessageDialog(null, message);
    }    
    public void beliButton11(ActionEvent event) throws IOException{
        Keranjang keranjang = new Keranjang(usernamePembeli, username11, idBarang11, 1, harga11);
        String message = "Produk dengan "+label11.getText()+" \nTelah di tambahkan ke list"+"\n klik button keranjang untuk melihat semua pesanan.";
        JOptionPane.showMessageDialog(null, message);
    }    
    public void beliButton12(ActionEvent event) throws IOException{
        Keranjang keranjang = new Keranjang(usernamePembeli, username12, idBarang12, 1, harga12);
        String message = "Produk dengan "+label12.getText()+" \nTelah di tambahkan ke list"+"\n klik button keranjang untuk melihat semua pesanan.";
        JOptionPane.showMessageDialog(null, message);
    }    
    @FXML
    public void keranjangButton(ActionEvent event) throws IOException{
       ((Node)(event.getSource())).getScene().getWindow().hide();
       tampil.Tampil("Keranjang");
    }
    
    @FXML
    public void likeButton(ActionEvent event) throws IOException{
       ((Node)(event.getSource())).getScene().getWindow().hide();
       tampil.Tampil("WhisList");        
    }
    
    @FXML
    public void keluarButton(ActionEvent event) throws IOException{
        List<Akun> listAkun = akunDao.getAllAkun();
        List<Pembeli> listPembeli = pembeliDao.getAllPembeli();
        for(Akun akun : listAkun){
            for(Pembeli pembeli : listPembeli){
            if(akun.getPenanda()==1 && akun.getUsername().equals(pembeli.getUsername())){
                Akun akun1 = new Akun(akun.getUsername(), akun.getPassword(), akun.getNama(), akun.getStatus(), 0);
                akunDao.updateAkun(akun1);
                ((Node)(event.getSource())).getScene().getWindow().hide();
                tampil.Tampil("Login");                
            }
            }
        }
    }    
    
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        loadData();
        loadData2();
    }
    
    
}
