/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.batik.controller;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javax.swing.JOptionPane;
import org.batik.dao.AkunDao;
import org.batik.dao.ProdukDao;
import org.batik.impl.AkunImplHibernate;
import org.batik.impl.ProdukImplHibernate;
import org.batik.model.Akun;
import org.batik.model.Produk;
import org.batik.model.Toko;

/**
 * FXML Controller class
 *
 * @author Amrianto Saragih
 */
public class TambahProdukController implements Initializable {

    @FXML
    private TextField idTF;
    @FXML
    private TextField namaTF;
    @FXML
    private TextArea deskripsiTF;
    @FXML
    private TextField stokTF;
    @FXML
    private ComboBox ukuranCB;        
    ObservableList<String>ukuran=FXCollections.observableArrayList("S","M","L","XL");
    @FXML
    private ComboBox jenisCB;        
    ObservableList<String>jenis=FXCollections.observableArrayList("Baju","Gaun","Aksessoris");
    @FXML
    private TextField hargaTF;
    @FXML
    private Label namaL;
    @FXML
    private Label urlLabel;
    private ProdukDao produkDao;
    private AkunDao akunDao;
    private TampilanController tampil;

    public TambahProdukController()
    {
        produkDao = ProdukImplHibernate.getProdukImpl();
        akunDao = AkunImplHibernate.getAkunImpl();
        tampil = new TampilanController();
    }

    public Label getUrlLabel() {
        return urlLabel;
    }
    
    public void loadData(){
        List<Akun> listAkun = akunDao.getAllAkun();
        if(listAkun.isEmpty()==false){
        for(Akun akun : listAkun){
            if(akun.getPenanda()==1){
                String nama = akun.getNama();
                namaL.setText("Hai "+nama);
                break;
            }
        }
        }
        jenisCB.setItems(jenis);
        ukuranCB.setItems(ukuran);
        
    }
    
    @FXML
    public void tambahButton(ActionEvent event){
        List<Akun> listAkun = akunDao.getAllAkun();
        for(Akun akun : listAkun){
            if(akun.getPenanda()==1){
                String id = idTF.getText();
                String nama = namaTF.getText();
                String deskripsi = deskripsiTF.getText();
                int stok = Integer.parseInt(stokTF.getText());
                String jenis = jenisCB.getValue().toString();
                double harga = Double.parseDouble(hargaTF.getText());
                String ukuran = ukuranCB.getValue().toString();
                String username = akun.getUsername();
                Produk produk = new Produk(username,id, nama, deskripsi, jenis, harga, ukuran, stok);
                produkDao.saveProduk(produk);
                inisialisasiAwal();
                String message = "Produk tersimpan";
                JOptionPane.showMessageDialog(null, message);                
            }
        }
    }
    
    public void inisialisasiAwal(){
        idTF.setText("");
        namaTF.setText("");
        deskripsiTF.setText("");
        stokTF.setText("");
        hargaTF.setText("");
    }
    
    @FXML
    public void cancelButton(ActionEvent event) throws IOException{
            ((Node)(event.getSource())).getScene().getWindow().hide();
            tampil.Tampil("Produk");                
    }

    @FXML
    public void browseGambar(){
        urlLabel.setText(produkDao.getPath());
        produkDao.setPath(urlLabel.getText());
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        loadData();
    }    
    
}
