
package org.batik.controller;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import org.batik.dao.AkunDao;
import org.batik.dao.TokoDao;
import org.batik.impl.AkunImplHibernate;
import org.batik.impl.TokoImplHibernate;
import org.batik.model.Akun;
import org.batik.model.Toko;

/**
 *
 * @author Amrianto Saragih
 */
public class UpdateProfilController implements Initializable{
    
    @FXML
    private TextField namaTF;
    @FXML
    private TextField alamatTF;
    @FXML
    private TextField noRekTF;
    @FXML
    private TextField noTelpTF;
    @FXML
    private TextArea deskripsiTF;
    @FXML
    private TextField usernameTF;
    @FXML
    private TextField passwordTF;
    @FXML
    private Label userLabel;
    private TokoDao tokoDao;
    private AkunDao akunDao;
    private TampilanController tampil;
    
    public UpdateProfilController() 
    {
        tokoDao = TokoImplHibernate.getTokoImpl();
        akunDao = AkunImplHibernate.getAkunImpl();
        tampil = new TampilanController();
    }
    
    public void loadData(){
        List<Toko> listToko = tokoDao.getAllToko();
        List<Akun> listAkun = akunDao.getAllAkun();
        try{
            for(Akun akun : listAkun){
                for(Toko toko : listToko){
                if(akun.getPenanda()==1 && akun.getUsername().equals(toko.getUsername())){
                    namaTF.setText(toko.getNamaToko());
                    alamatTF.setText(toko.getAlamat());
                    noRekTF.setText(toko.getNoRekBank());
                    noTelpTF.setText(toko.getNoTelp());
                    deskripsiTF.setText(toko.getDeskripsiToko());
                    usernameTF.setText(toko.getUsername());
                    passwordTF.setText(toko.getPassword());
                }
               }      
            }               
        }catch(NullPointerException ne){
            System.out.println(""+ne.getMessage());
        }
    }

    @FXML
    public void updateButton(ActionEvent event) throws IOException{
        String nama = namaTF.getText();
        String alamat = alamatTF.getText();
        String noRek = noRekTF.getText();
        String noTelp = noTelpTF.getText();
        String desKripsi = deskripsiTF.getText();
        String username = usernameTF.getText();
        String password = passwordTF.getText();
        Toko toko = new Toko(nama, alamat, desKripsi, noTelp, noRek, username, password);
        Akun akun = new Akun(username, password, nama, "Toko", 1);
        akunDao.updateAkun(akun);
        tokoDao.updateToko(toko, tokoDao.getP());
        inisialisasiAwalInputan();
        ((Node)(event.getSource())).getScene().getWindow().hide();
        tampil.Tampil("profilToko");              
    }
    
    public void inisialisasiAwalInputan(){
        namaTF.setText("");
        alamatTF.setText("");
        noRekTF.setText("");
        noTelpTF.setText("");
        deskripsiTF.setText("");
        usernameTF.setText("");
        passwordTF.setText("");
    }
    
    @FXML
    public void browseFoto(ActionEvent event){
        userLabel.setText(tokoDao.getPath());
        tokoDao.setPath(userLabel.getText());
    }
    
    @FXML
    public void cancelButton(ActionEvent event) throws IOException{
        ((Node)(event.getSource())).getScene().getWindow().hide();
        tampil.Tampil("profilToko");
    }
    
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        loadData();
    }   
}