
package org.batik.controller;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javax.swing.JOptionPane;
import org.batik.dao.AkunDao;
import org.batik.dao.TokoDao;
import org.batik.impl.AkunImplHibernate;
import org.batik.impl.TokoImplHibernate;
import org.batik.model.Akun;
import org.batik.model.Toko;

/**
 *
 * @author Amrianto Saragih
 */
public class RegisterTokoController implements Initializable{
    @FXML
    private TextField namaTF;
    @FXML
    private TextField alamatTF;
    @FXML
    private TextArea deskripsiTF;
    @FXML
    private TextField noRekTF;
    @FXML
    private TextField noTelpTF;
    @FXML
    private TextField usernameTF;    
    @FXML
    private PasswordField passwordF;
    @FXML
    private Label userLabel;
    
    private AkunDao akunDao;
    private TokoDao tokoDao;
    private TampilanController tampil;

    public RegisterTokoController() 
    {
        akunDao = AkunImplHibernate.getAkunImpl();
        tokoDao = TokoImplHibernate.getTokoImpl();
        tampil = new TampilanController();
    }

    @FXML
    public void saveButton(ActionEvent event) throws IOException{
        String nama = namaTF.getText();
        String alamat = alamatTF.getText();
        String deskripsi = deskripsiTF.getText();
        String noRek = noRekTF.getText();
        String noTelp = noTelpTF.getText();
        String username = usernameTF.getText();
        String password = passwordF.getText();
        if(akunDao.checkUser(username)==false){
            String message = "Username sudah ada";
            JOptionPane.showMessageDialog(null, message);
        }else if(nama.equals("")||alamat.equals("")||deskripsi.equals("")||noTelp.equals("")||username.equals("")||password.equals("")){
            String message = "Tidak boleh ada yang kosong";
            JOptionPane.showMessageDialog(null, message);            
        }
        else{
            Toko toko = new Toko(nama, alamat, deskripsi, noTelp, noRek, username, password);
            tokoDao.saveToko(toko);
            Akun akun = new Akun(username, password, nama, "Toko", 0);
            akunDao.saveAkun(akun);
            inisialisasiAwalInputan();
            ((Node)(event.getSource())).getScene().getWindow().hide();
            tampil.Tampil("Login");
        }
    }
    
    public void inisialisasiAwalInputan(){
        namaTF.setText("");
        alamatTF.setText("");
        deskripsiTF.setText("");
        noRekTF.setText("");
        noTelpTF.setText("");
        usernameTF.setText("");
        passwordF.setText("");
    }
    
    @FXML
    public void batalButton(ActionEvent event) throws IOException{
        ((Node)(event.getSource())).getScene().getWindow().hide();
        tampil.Tampil("Login");
    }
    
    @FXML
    public void getFoto(){
        userLabel.setText(tokoDao.getPath());
        tokoDao.setPath(userLabel.getText());
    }
    
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        
    }
    
    
    
}
