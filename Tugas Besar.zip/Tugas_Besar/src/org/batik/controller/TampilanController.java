
package org.batik.controller;

import java.io.IOException;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author Amrianto Saragih
 */
public class TampilanController {
      
    public void Tampil(String tampil) throws IOException{
        if(tampil.equalsIgnoreCase("Login")){   
            Parent parent = FXMLLoader.load(getClass().getResource("/org/batik/view/Login.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(parent);
            stage.setScene(scene);
            stage.show();
         }else if(tampil.equalsIgnoreCase("BerandaPembeli")){
            Parent parent = FXMLLoader.load(getClass().getResource("/org/batik/view/BerandaPembeli.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(parent);
            stage.setScene(scene);
            stage.show();             
         }else if(tampil.equalsIgnoreCase("BerandaPengirim")){
            Parent parent = FXMLLoader.load(getClass().getResource("/org/batik/view/BerandaPengirim.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(parent);
            stage.setScene(scene);
            stage.show();             
         }else if(tampil.equalsIgnoreCase("BerandaAdmin")){
            Parent parent = FXMLLoader.load(getClass().getResource("/org/batik/view/BerandaAdmin.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(parent);
            stage.setScene(scene);
            stage.show();             
         }else if(tampil.equalsIgnoreCase("Konfirmasi")){
            Parent parent = FXMLLoader.load(getClass().getResource("/org/batik/view/Konfirmasi.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(parent);
            stage.setScene(scene);
            stage.show();             
         }else if(tampil.equalsIgnoreCase("Register")){
            Parent parent = FXMLLoader.load(getClass().getResource("/org/batik/view/Register.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(parent);
            stage.setScene(scene);
            stage.show();             
         }else if(tampil.equalsIgnoreCase("BerandaToko")){
            Parent parent = FXMLLoader.load(getClass().getResource("/org/batik/view/BerandaToko.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(parent);
            stage.setScene(scene);
            stage.show();             
         }else if(tampil.equalsIgnoreCase("Update")){
            Parent parent = FXMLLoader.load(getClass().getResource("/org/batik/view/Update.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(parent);
            stage.setScene(scene);
            stage.show();             
         }else if(tampil.equalsIgnoreCase("forgetPassword")){
            Parent parent = FXMLLoader.load(getClass().getResource("/org/batik/view/forgetPassword.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(parent);
            stage.setScene(scene);
            stage.show();              
         }else if(tampil.equalsIgnoreCase("UpdateProfil")){
            Parent parent = FXMLLoader.load(getClass().getResource("/org/batik/view/UPDATEPROFIL.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(parent);
            stage.setScene(scene);
            stage.show();              
         }else if(tampil.equalsIgnoreCase("RegisterToko")){
            Parent parent = FXMLLoader.load(getClass().getResource("/org/batik/view/RegisterToko.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(parent);
            stage.setScene(scene);
            stage.show();              
         }else if(tampil.equalsIgnoreCase("profilToko")){
            Parent parent = FXMLLoader.load(getClass().getResource("/org/batik/view/profilToko.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(parent);
            stage.setScene(scene);
            stage.show();             
         }else if(tampil.equalsIgnoreCase("Produk")){
            Parent parent = FXMLLoader.load(getClass().getResource("/org/batik/view/Produk.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(parent);
            stage.setScene(scene);
            stage.show();
         }else if(tampil.equalsIgnoreCase("TambahBarang")){
            Parent parent = FXMLLoader.load(getClass().getResource("/org/batik/view/ADD_BARANG.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(parent);
            stage.setScene(scene);
            stage.show();             
         }else if(tampil.equalsIgnoreCase("LihatProduk")){
            Parent parent = FXMLLoader.load(getClass().getResource("/org/batik/view/LihatProduk.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(parent);
            stage.setScene(scene);
            stage.show();              
         }else if(tampil.equalsIgnoreCase("Keranjang")){
            Parent parent = FXMLLoader.load(getClass().getResource("/org/batik/view/Keranjang.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(parent);
            stage.setScene(scene);
            stage.show();             
         }else if(tampil.equalsIgnoreCase("WhisList")){
            Parent parent = FXMLLoader.load(getClass().getResource("/org/batik/view/WhisList.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(parent);
            stage.setScene(scene);
            stage.show();              
         }
        
    }
}
