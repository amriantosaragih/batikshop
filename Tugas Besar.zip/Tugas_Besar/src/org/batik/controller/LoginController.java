
package org.batik.controller;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.ComboBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javax.swing.JOptionPane;
import org.batik.dao.AkunDao;
import org.batik.impl.AkunImplHibernate;
import org.batik.model.Akun;

/**
 *
 * @author Amrianto Saragih
 */
public class LoginController implements Initializable{
     @FXML
     private TextField usernameTF;
     @FXML
     private PasswordField passwordF;
     @FXML
     private RadioButton remember;
     @FXML
     private ComboBox statusCB;
     ObservableList<String>status=FXCollections.observableArrayList("Pembeli", "Toko");
     private AkunDao akunDao;
     private TampilanController tampil;

    public LoginController() {
        akunDao = AkunImplHibernate.getAkunImpl();
        tampil = new TampilanController();
    }
     
    public void loadData(){
        statusCB.setItems(status);
    }
     @FXML
     public void loginButton(ActionEvent event) throws IOException{
         int status=0;
         List<Akun> listAkun = akunDao.getAllAkun();
         String username = usernameTF.getText();
         String password = passwordF.getText();
         if(username.isEmpty()||password.isEmpty()){
                 String message = "Tidak boleh kosong";
                 JOptionPane.showMessageDialog(null, message);
         }else{
         for(int i=0; i<listAkun.size(); i++){
             if(listAkun.get(i).getUsername().equals(username)&&listAkun.get(i).getPassword().equals(password)){
                 if(listAkun.get(i).getStatus().equals("Pembeli")){
                   ((Node)(event.getSource())).getScene().getWindow().hide(); 
                   tampil.Tampil("BerandaPembeli");
                    Akun a = new Akun(username, password, listAkun.get(i).getNama(), listAkun.get(i).getStatus(), 1);
                    akunDao.updateAkun(a);
                    status=1;
                 }else if(listAkun.get(i).getStatus().equals("Toko")){
                   ((Node)(event.getSource())).getScene().getWindow().hide(); 
                   tampil.Tampil("BerandaToko");
                    Akun a = new Akun(username, password, listAkun.get(i).getNama(), listAkun.get(i).getStatus(), 1);
                    akunDao.updateAkun(a);     
                    status=1;
                 }else if(listAkun.get(i).getStatus().equals("Pengirim")){
                   ((Node)(event.getSource())).getScene().getWindow().hide(); 
                   tampil.Tampil("BerandaPengirim");
                    Akun a = new Akun(username, password, listAkun.get(i).getNama(), listAkun.get(i).getStatus(), 1);
                    akunDao.updateAkun(a);
                    status=1;
                 }else if(listAkun.get(i).getStatus().equals("Admin")){
                   ((Node)(event.getSource())).getScene().getWindow().hide(); 
                   tampil.Tampil("BerandaAdmin");
                    Akun a = new Akun(username, password, listAkun.get(i).getNama(), listAkun.get(i).getStatus(), 1);
                    akunDao.updateAkun(a); 
                    status=1;
                 }                
              }                                         
         }
        if(status==0){
            String message = "Username atau password salah";
            JOptionPane.showMessageDialog(null, message);
        }
     }
   }
     
     @FXML
     public void registerButton(ActionEvent event) throws IOException
     {
         String status = statusCB.getValue().toString();
         if(status.equalsIgnoreCase("Pembeli")){
         ((Node)(event.getSource())).getScene().getWindow().hide();
         tampil.Tampil("Register");
         }else if(status.equalsIgnoreCase("Toko")){
         ((Node)(event.getSource())).getScene().getWindow().hide();
         tampil.Tampil("RegisterToko");             
         }
     }
     
     @FXML
     public void forgetPassword(ActionEvent event) throws IOException{
         ((Node)(event.getSource())).getScene().getWindow().hide();
         tampil.Tampil("forgetPassword");
     }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        loadData();
    }
}
