/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.batik.controller;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import org.batik.dao.AkunDao;
import org.batik.dao.ProdukDao;
import org.batik.dao.TokoDao;
import org.batik.impl.AkunImplHibernate;
import org.batik.impl.ProdukImplHibernate;
import org.batik.impl.TokoImplHibernate;
import org.batik.model.Akun;
import org.batik.model.Produk;
import org.batik.model.Toko;

/**
 * FXML Controller class
 *
 * @author Amrianto Saragih
 */
public class LihatProdukController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    private Label userLabel;
    @FXML
    private Label idLabel;
    @FXML
    private Label namaL;
    @FXML
    private TextArea deskripsiTA;
    @FXML
    private ImageView image;
    @FXML
    private ImageView image1;
    @FXML
    private ImageView image2;
    @FXML
    private ImageView image3;
    @FXML
    private ImageView image4;
    private ProdukDao produkDao;
    private AkunDao akunDao;
    private TokoDao tokoDao;
    private TampilanController tampil;

    public LihatProdukController() {
        produkDao = ProdukImplHibernate.getProdukImpl();
        akunDao = AkunImplHibernate.getAkunImpl();
        tampil = new TampilanController();
        tokoDao = TokoImplHibernate.getTokoImpl();
    }
    
    public void loadData(){
        List<Produk> listProduk = produkDao.getAllProduk();
        List<Toko> listToko = tokoDao.getAllToko();
        try{
            for(int i=0; i<listProduk.size(); i++){
                for(Toko toko : listToko){
                    if(listProduk.get(i).getUsernameToko().equals(toko.getUsername())){
                    userLabel.setText("Hai , "+toko.getNamaToko());
                    }
                }
                if(listProduk.get(i).getId().equalsIgnoreCase(produkDao.getIdBarang())){ 
                    produkDao.getDataProduk(listProduk.get(i).getUsernameToko());
                    idLabel.setText(listProduk.get(i).getId());
                    namaL.setText(listProduk.get(i).getNama());
                    deskripsiTA.setText(listProduk.get(i).getDeskripsi());
                    image.setImage(new Image("file:gambar.jpg"));
                }
            }
        }catch(NullPointerException ne){
            System.out.println(ne.getMessage());
        }
    }
    
    @FXML
    public void berandaButton(ActionEvent event) throws IOException{
        ((Node)(event.getSource())).getScene().getWindow().hide();
        tampil.Tampil("BerandaToko");
    }

    @FXML
    public void profilButton(ActionEvent event) throws IOException{
        ((Node)(event.getSource())).getScene().getWindow().hide();
        tampil.Tampil("ProfilToko");
    }
    
    @FXML
    public void produkButton(ActionEvent event) throws IOException{
       ((Node)(event.getSource())).getScene().getWindow().hide();
        tampil.Tampil("Produk");        
    }

    @FXML
    public void keluarButton(ActionEvent event) throws IOException{
        List<Akun> listAkun = akunDao.getAllAkun();
        List<Produk> listProduk = produkDao.getAllProduk();
        for(Akun akun : listAkun){
            for(Produk produk : listProduk){
            if(akun.getPenanda()==1 && akun.getUsername().equals(produk.getUsernameToko())){
                Akun akun1 = new Akun(akun.getUsername(), akun.getPassword(), akun.getNama(), akun.getStatus(), 0);
                akunDao.updateAkun(akun1);
                ((Node)(event.getSource())).getScene().getWindow().hide();
                tampil.Tampil("Login");                
                }
            }
        }
    }    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        loadData();
    }    
    
}
