/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.batik.controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DialogPane;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javax.swing.JOptionPane;
import org.batik.dao.AdminDao;
import org.batik.dao.AkunDao;
import org.batik.dao.PembeliDao;
import org.batik.dao.PengirimDao;
import org.batik.dao.TokoDao;
import org.batik.impl.AdminImplHibernate;
import org.batik.impl.AkunImplHibernate;
import org.batik.impl.PembeliImplHibernate;
import org.batik.impl.PengirimImplHibernate;
import org.batik.impl.TokoImplHibernate;
import org.batik.model.Admin;
import org.batik.model.Akun;
import org.batik.model.Pembeli;
import org.batik.model.Toko;

/**
 *
 * @author Amrianto Saragih
 */
public class RegisterController implements Initializable{
       
    @FXML
    private TextField namaTF;
    @FXML
    private TextField alamatTF;
    @FXML
    private TextField usernameTF;
    @FXML
    private PasswordField passwordF;
    @FXML
    private Label userLabel;
    @FXML
    private ComboBox jenisKelaminCB;
    ObservableList<String>jenisKelamin=FXCollections.observableArrayList("Pria","Wanita");
    @FXML
    private TextField tempatTF;
    @FXML
    private TextField tanggalLahirTF;
    @FXML
    private TextField noTelpTF;
    @FXML
    private TextField pekerjaanTF;
    private AkunDao akunDao;
    private PembeliDao pembeliDao;
    private PengirimDao pengirimDao;
    private TokoDao tokoDao;
    private TampilanController tampil;
    private AdminDao adminDao;

    public RegisterController() 
    {
        akunDao = AkunImplHibernate.getAkunImpl();
        pembeliDao = PembeliImplHibernate.getPembeliImpl();
        pengirimDao = PengirimImplHibernate.getPengirimImpl();
        tokoDao = TokoImplHibernate.getTokoImpl();
        adminDao = AdminImplHibernate.getAdminImpl();
        tampil = new TampilanController();
    }
    
    public void loadData(){
        jenisKelaminCB.setItems(jenisKelamin);
    }
    
    @FXML
    public void daftarButton(ActionEvent event) throws IOException{
        String user = usernameTF.getText();
        String pass = passwordF.getText();
        String tempat = tempatTF.getText();
        String noTelp = noTelpTF.getText();
        String tglLahir = tanggalLahirTF.getText();
        String nama = namaTF.getText();
        String pekerjaan = pekerjaanTF.getText();
        String alamat = alamatTF.getText();
        String jk = jenisKelaminCB.getValue().toString();
        
        if(user.isEmpty()||pass.isEmpty()||tempat.isEmpty()||nama.isEmpty()||alamat.isEmpty()||jk.isEmpty()||noTelp.isEmpty()||tglLahir.isEmpty()||pekerjaan.isEmpty())
        {
            String message = "Tidak boleh ada yang kosong";
            JOptionPane.showMessageDialog(null, message);
        }else{
            if(akunDao.checkUser(user)==true){
                    Pembeli p = new Pembeli(nama, alamat, jk, tempat, tglLahir, noTelp, user, pass);
                    pembeliDao.savePembeli(p);
                    Akun akun = new Akun(user, pass, nama, "Pembeli", 0);
                    akunDao.saveAkun(akun);
                    inisialisasiR();
                    ((Node)(event.getSource())).getScene().getWindow().hide();
                    tampil.Tampil("Login");                    
            }else{
                String message = "Username sudah ada";
                JOptionPane.showMessageDialog(null, message);                
            }
        }   
      }
         
    public void showMessageDialog()
    {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmation Dialog");
        alert.setHeaderText("Your account has been created.");
        alert.setContentText("To continue, press button OK.");
        DialogPane dialogPane = alert.getDialogPane();
        dialogPane.getStylesheets().add(getClass().getResource("myDialogs.css").toExternalForm());
        dialogPane.getStyleClass().add("myDialog");
        alert.showAndWait();
    }
    
    public void showMessageDialogR()
    {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmation Dialog");
        alert.setHeaderText("Your account can't be created.");
        alert.setContentText("Press OK to re-register");
        DialogPane dialogPane = alert.getDialogPane();
        dialogPane.getStylesheets().add(getClass().getResource("myDialogs.css").toExternalForm());
        dialogPane.getStyleClass().add("myDialog");
        alert.showAndWait();
           
    }    

    
    public void inisialisasiR()
    {
        namaTF.setText("");
        alamatTF.setText("");
        usernameTF.setText("");
        passwordF.setText("");
        pekerjaanTF.setText("");
        jenisKelaminCB.setValue("--- Pilih Jenis Kelamin ---");
        tempatTF.setText("");
        tanggalLahirTF.setText("");
        noTelpTF.setText("");
    }
    
    @FXML
    public void btnBatal(ActionEvent event) throws IOException 
    {
            ((Node)(event.getSource())).getScene().getWindow().hide();                
            tampil.Tampil("Login");
    }    

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        loadData();
    }
    
}
