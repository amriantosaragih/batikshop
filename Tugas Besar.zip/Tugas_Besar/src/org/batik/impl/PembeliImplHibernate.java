/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.batik.impl;

import java.util.List;
import org.batik.dao.PembeliDao;
import org.batik.model.Pembeli;
import org.batik.util.HibernateUtil;
import org.hibernate.Session;

/**
 *
 * @author Amrianto Saragih
 */
public class PembeliImplHibernate implements PembeliDao{
    private static final PembeliImplHibernate pembeliImpl = new PembeliImplHibernate();
    
    private PembeliImplHibernate(){
        
    }
    
    public static PembeliImplHibernate getPembeliImpl(){
        return pembeliImpl;
    }
    
    @Override
    public void savePembeli(Pembeli pembeli) {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        session.save(pembeli);
        session.getTransaction().commit();
        HibernateUtil.closeSession();
    }

    @Override
    public void updatePembeli(Pembeli pembeli) {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        session.update(pembeli);
        session.getTransaction().commit();
        HibernateUtil.closeSession();
    }

    @Override
    public List<Pembeli> getAllPembeli() {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        List<Pembeli> listPembeli = session.createCriteria(Pembeli.class).list();
        session.getTransaction().commit();
        HibernateUtil.closeSession();
        return listPembeli; 
    }

    @Override
    public void deletePembeli(Pembeli pembeli) {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        session.delete(pembeli);
        session.getTransaction().commit();
        HibernateUtil.closeSession();
    }
     
}
