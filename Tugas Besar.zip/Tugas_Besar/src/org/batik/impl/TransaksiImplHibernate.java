/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.batik.impl;

/**
 *
 * @author Amrianto Saragih
 */
public class TransaksiImplHibernate {
    private static final TransaksiImplHibernate transaksiImpl = new TransaksiImplHibernate();
    
    private TransaksiImplHibernate(){
        
    }
    
    public static TransaksiImplHibernate getTransaksiImpl(){
        return transaksiImpl;
    }
    
}
