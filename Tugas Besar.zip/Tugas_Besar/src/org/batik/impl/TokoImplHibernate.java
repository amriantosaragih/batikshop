/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.batik.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import org.batik.dao.TokoDao;
import org.batik.model.Toko;
import org.batik.util.HibernateUtil;
import org.hibernate.Session;

/**
 *
 * @author Amrianto Saragih
 */
public class TokoImplHibernate implements TokoDao{
    private static final TokoImplHibernate tokoImpl = new TokoImplHibernate();
    private String URL;
    private String path;
    
    private TokoImplHibernate(){
        
    }
    
    public static TokoImplHibernate getTokoImpl(){
        return tokoImpl;
    } 
    
    @Override
    public void setPath(String path){
        this.path = path;
    }
    
    @Override
    public String getP(){
        return path;
    }
    
    @Override
    public void saveToko(Toko toko) {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        File file = new File(path);
        byte[] fileBytes = null;
        try {
            FileInputStream fis = new FileInputStream(file);
            fileBytes = new byte[(int) file.length()];
            fis.read(fileBytes);
            fis.close();
        } catch (FileNotFoundException ex) {

        } catch (IOException ex) {

        }
        toko.setFoto(fileBytes);
        session.save(toko);
        session.getTransaction().commit();
        HibernateUtil.closeSession();         
    }
    @Override
    public List<Toko> getAllToko() {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        List<Toko> listToko = session.createCriteria(Toko.class).list();
        session.getTransaction().commit();
        HibernateUtil.closeSession();
        return listToko; 
    }

    @Override
    public void deleteToko(Toko toko) {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        session.delete(toko);
        session.getTransaction().commit();
        HibernateUtil.closeSession();
    }

    @Override
    public void updateToko(Toko toko, String pathFoto) {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        File file = new File(pathFoto);
        byte[] fileBytes = null;
        try {
            FileInputStream fis = new FileInputStream(file);
            fileBytes = new byte[(int) file.length()];
            fis.read(fileBytes);
            fis.close();
        } catch (FileNotFoundException ex) {

        } catch (IOException ex) {

        }
        toko.setFoto(fileBytes);
        session.update(toko);
        session.getTransaction().commit();
        HibernateUtil.closeSession();
    }

    @Override
    public Toko getDataToko(String username) {
        OutputStream os = null;
        Toko toko = new Toko();
        try {
            os = new FileOutputStream(new File("foto.jpg"));
            for (Toko listToko : getAllToko()) {
                if (listToko.getUsername().equalsIgnoreCase(username)) {
                    toko = listToko;
                    os.write(listToko.getFoto());
                    URL = os.toString();
                    os.close();
                    break;
                }
            }

        } catch (FileNotFoundException ex) {
        } catch (IOException ex) {
        }

        return toko;
    }

    @Override
    public void getFoto(String username) {
        OutputStream os = null;
        try {
            os = new FileOutputStream(new File("foto.jpg"));
            for (Toko toko : getAllToko()) {
                if (toko.getUsername().equalsIgnoreCase(username)) {
                    os.write(toko.getFoto());
                    URL = os.toString();
                    os.close();
                    break;
                }
            }
        } catch (FileNotFoundException ex) {

        } catch (IOException ex) {

        }
    }

    @Override
    public String getURLFoto() {
        return this.URL;
    }

    @Override
    public String getPath() {
        String path = new String();
        FileChooser filechose = new FileChooser();
        File file;
        Stage stage = new Stage();
        file = filechose.showOpenDialog(stage);
        path = (String) file.getAbsolutePath();
        return path;
    }
    
    

    
}
