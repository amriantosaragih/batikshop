/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.batik.impl;

import java.util.List;
import org.batik.dao.PengirimDao;
import org.batik.model.Pengirim;
import org.batik.util.HibernateUtil;
import org.hibernate.Session;

/**
 *
 * @author Amrianto Saragih
 */
public class PengirimImplHibernate implements PengirimDao{
    private static final PengirimImplHibernate pengirimImpl = new PengirimImplHibernate();
    
    private PengirimImplHibernate(){
        
    }
    
    public static PengirimImplHibernate getPengirimImpl(){
        return pengirimImpl;
    }
    
    @Override
    public void savePengirim(Pengirim pengirim) {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        session.save(pengirim);
        session.getTransaction().commit();
        HibernateUtil.closeSession(); 
    }

    @Override
    public void updatePengirim(Pengirim pengirim) {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        session.update(pengirim);
        session.getTransaction().commit();
        HibernateUtil.closeSession();
    }

    @Override
    public List<Pengirim> getAllPengirim() {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        List<Pengirim> listPengirim = session.createCriteria(Pengirim.class).list();
        session.getTransaction().commit();
        HibernateUtil.closeSession();
        return listPengirim; 
    }

    @Override
    public void deletePengirim(Pengirim pengirim) {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        session.delete(pengirim);
        session.getTransaction().commit();
        HibernateUtil.closeSession();
    }
    
}
