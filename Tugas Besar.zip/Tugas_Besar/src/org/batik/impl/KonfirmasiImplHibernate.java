/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.batik.impl;

/**
 *
 * @author Amrianto Saragih
 */
public class KonfirmasiImplHibernate {
    private static final KonfirmasiImplHibernate konfirmasiImpl = new KonfirmasiImplHibernate();
    
    private KonfirmasiImplHibernate(){
        
    }
    
    public static KonfirmasiImplHibernate getKonfirmasiImpl(){
        return konfirmasiImpl;
    }
}
