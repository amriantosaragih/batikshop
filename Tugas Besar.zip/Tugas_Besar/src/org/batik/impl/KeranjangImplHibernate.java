/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.batik.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import org.batik.dao.KeranjangDao;
import org.batik.model.Keranjang;
import org.batik.util.HibernateUtil;
import org.hibernate.Session;

/**
 *
 * @author Amrianto Saragih
 */
public class KeranjangImplHibernate implements KeranjangDao{
    private static final KeranjangImplHibernate keranjangImpl = new KeranjangImplHibernate();
    
    private KeranjangImplHibernate(){
        
    }
    
    public static KeranjangImplHibernate getkeranjangImpl(){
        return keranjangImpl;
    }

    @Override
    public void saveKeranjang(Keranjang keranjang) {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        session.save(keranjang);
        session.getTransaction().commit();
        HibernateUtil.closeSession();          
    }

    @Override
    public List<Keranjang> getAllKeranjang() {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        List<Keranjang> listKeranjang = session.createCriteria(Keranjang.class).list();
        session.getTransaction().commit();
        HibernateUtil.closeSession();
        return listKeranjang; 
    }

    @Override
    public void deleteProduk(Keranjang keranjang) {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        session.delete(keranjang);
        session.getTransaction().commit();
        HibernateUtil.closeSession();
    }
}
