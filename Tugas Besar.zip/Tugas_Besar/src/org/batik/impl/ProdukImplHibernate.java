/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.batik.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import org.batik.dao.ProdukDao;
import org.batik.model.Produk;
import org.batik.util.HibernateUtil;
import org.hibernate.Session;

/**
 *
 * @author Amrianto Saragih
 */
public class ProdukImplHibernate implements ProdukDao{
    private String URL;
    private String path;
    private String id;
    private static final ProdukImplHibernate produkImpl = new ProdukImplHibernate();

    private ProdukImplHibernate() 
    {
    
    }
 
    public static ProdukImplHibernate getProdukImpl(){
        return produkImpl;
    }
    
    @Override
    public void setPath(String path) {
        this.path = path;
    }
    
    @Override
    public String getP(){
        return path;
    }
    
    @Override
    public void saveProduk(Produk produk) {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        File file = new File(path);
        byte[] fileBytes = null;
        try {
            FileInputStream fis = new FileInputStream(file);
            fileBytes = new byte[(int) file.length()];
            fis.read(fileBytes);
            fis.close();
        } catch (FileNotFoundException ex) {

        } catch (IOException ex) {

        }
        produk.setGambar(fileBytes);
        session.save(produk);
        session.getTransaction().commit();
        HibernateUtil.closeSession(); 
    }

    @Override
    public void updateProduk(String username, String pathFoto) {
        Produk produk = getDataProduk(username);
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        File file = new File(pathFoto);
        byte[] fileBytes = null;
        try {
            FileInputStream fis = new FileInputStream(file);
            fileBytes = new byte[(int) file.length()];
            fis.read(fileBytes);
            fis.close();
        } catch (FileNotFoundException ex) {

        } catch (IOException ex) {

        }
        produk.setGambar(fileBytes);
        session.update(produk);
        session.getTransaction().commit();
        HibernateUtil.closeSession();        
    }

    @Override
    public List<Produk> getAllProduk() {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        List<Produk> listProduk = session.createCriteria(Produk.class).list();
        session.getTransaction().commit();
        HibernateUtil.closeSession();
        return listProduk; 
    }

    @Override
    public void deleteProduk(Produk produk) {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        session.delete(produk);
        session.getTransaction().commit();
        HibernateUtil.closeSession();
    }

    @Override
    public Produk getDataProduk(String id) {
        OutputStream os = null;
        Produk produk = new Produk();
        try {
            for (Produk listProduk : getAllProduk()) {
                if (listProduk.getId().equalsIgnoreCase(id)) {
                   os = new FileOutputStream(new File("gambar.jpg"));                    
                    produk = listProduk;
                    os.write(listProduk.getGambar());
                    URL = os.toString();
                    os.close();
                    break;
                }
            }

        } catch (FileNotFoundException ex) {
        } catch (IOException ex) {
        }

        return produk;
    }

    @Override
    public void getFoto(String id) {
        OutputStream os = null;
        try {
            os = new FileOutputStream(new File("gambar.jpg"));
            for (Produk listProduk : getAllProduk()) {
                if (listProduk.getId().equalsIgnoreCase(id)) {
                    os.write(listProduk.getGambar());
                    URL = os.toString();
                    os.close();
                    break;
                }
            }
        } catch (FileNotFoundException ex) {

        } catch (IOException ex) {

        }
    }

    @Override
    public String getURLFoto() {
        return this.URL;
    }
    
    @Override
    public String getPath() {
        String path = new String();
        FileChooser filechose = new FileChooser();
        File file;
        Stage stage = new Stage();
        file = filechose.showOpenDialog(stage);
        path = (String) file.getAbsolutePath();
        return path;        
    }

    
    @Override
    public void setIdBarang(String id) {
        this.id=id;
    }

    @Override
    public String getIdBarang() {
        return this.id;
    }
}
