/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.batik.impl;

/**
 *
 * @author Amrianto Saragih
 */
public class ChatsImplHibernate {
    private static final ChatsImplHibernate chatsImpl = new ChatsImplHibernate();

    private ChatsImplHibernate() {
    
    }
    
    public static ChatsImplHibernate getChatsImpl(){
        return chatsImpl;
    }
}
