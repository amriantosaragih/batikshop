/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.batik.impl;

import java.util.List;
import org.batik.dao.AkunDao;
import org.batik.model.Akun;
import org.batik.util.HibernateUtil;
import org.hibernate.Session;

/**
 *
 * @author Amrianto Saragih
 */
public class AkunImplHibernate implements AkunDao{
    private static final AkunImplHibernate akunImpl = new AkunImplHibernate();
            
   private AkunImplHibernate(){
       
   }        
   
   public static AkunImplHibernate getAkunImpl(){
       return akunImpl;
   }
           
    @Override
    public void saveAkun(Akun akun) {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        session.save(akun);
        session.getTransaction().commit();
        HibernateUtil.closeSession();
    }

    @Override
    public void updateAkun(Akun akun) {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        session.update(akun);
        session.getTransaction().commit();
        HibernateUtil.closeSession();
    }

    @Override
    public List<Akun> getAllAkun() {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        List<Akun> listAkun = session.createCriteria(Akun.class).list();
        session.getTransaction().commit();
        HibernateUtil.closeSession();
        return listAkun;
    }

    @Override
    public void deleteAkun(Akun akun) {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        session.delete(akun);
        session.getTransaction().commit();
        HibernateUtil.closeSession();
    }

    @Override
    public boolean checkUser(String username) {
        boolean ada = true;
        List<Akun> listAkun = getAllAkun();
            for(Akun akun : listAkun){
                if(akun.getUsername().equals(username)){
                   ada = false;
                }else{
                    ada = true;
                }
            }
        return ada;    
    }
    
}
