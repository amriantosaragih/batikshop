/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.batik.impl;

import java.util.List;
import org.batik.dao.AdminDao;
import org.batik.model.Admin;
import org.batik.util.HibernateUtil;
import org.hibernate.Session;

/**
 *
 * @author Amrianto Saragih
 */
public class AdminImplHibernate implements AdminDao{
    private static final AdminImplHibernate adminImpl = new AdminImplHibernate();

    private AdminImplHibernate() {
    
    }  
    
    public static AdminImplHibernate getAdminImpl(){
        return adminImpl;
    }
    
    @Override
    public void saveAdmin(Admin admin) {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        session.save(admin);
        session.getTransaction().commit();
        HibernateUtil.closeSession();
    }

    @Override
    public void updateAdmin(Admin admin) {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        session.update(admin);
        session.getTransaction().commit();
        HibernateUtil.closeSession();
    }

    @Override
    public void deleteAdmin(Admin admin) {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        session.delete(admin);
        session.getTransaction().commit();
        HibernateUtil.closeSession();
    }

    @Override
    public List<Admin> detAllAdmin() {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        List<Admin> listAdmin = session.createCriteria(Admin.class).list();
        session.getTransaction().commit();
        HibernateUtil.closeSession();
        return listAdmin;
    }
    
}
