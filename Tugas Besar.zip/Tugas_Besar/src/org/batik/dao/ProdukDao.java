/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.batik.dao;

import java.util.List;
import org.batik.model.Produk;

/**
 *
 * @author Amrianto Saragih
 */
public interface ProdukDao {
    public void saveProduk(Produk produk);
    public void updateProduk(String username, String pathFoto);
    public List<Produk> getAllProduk();
    public void deleteProduk(Produk produk);  
    public Produk getDataProduk(String username);
    public void getFoto(String username);
    public String getURLFoto();
    public String getPath();  
    public void setPath(String path);
    public String getP();
    public void setIdBarang(String id);
    public String getIdBarang();
}
