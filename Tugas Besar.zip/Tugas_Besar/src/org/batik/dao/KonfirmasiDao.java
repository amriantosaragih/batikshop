/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.batik.dao;

import java.util.List;
import org.batik.model.Konfirmasi;

/**
 *
 * @author Amrianto Saragih
 */
public interface KonfirmasiDao {
    public void saveKonfirmasi(Konfirmasi konfirmasi);
    public List<Konfirmasi> getAllKonfirmasi();
    public void deleteKonfirmasi(Konfirmasi konfirmasi);
}
