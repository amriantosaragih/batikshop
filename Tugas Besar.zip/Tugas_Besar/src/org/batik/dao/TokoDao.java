/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.batik.dao;

import java.util.List;
import org.batik.model.Toko;

/**
 *
 * @author Amrianto Saragih
 */
public interface TokoDao {
    public void saveToko(Toko toko);
    public void updateToko(Toko toko, String pathFoto);
    public List<Toko> getAllToko();
    public void deleteToko(Toko toko);  
    public Toko getDataToko(String username);
    public void getFoto(String username);
    public String getURLFoto();
    public String getPath();
    public void setPath(String path);
    public String getP();
}
