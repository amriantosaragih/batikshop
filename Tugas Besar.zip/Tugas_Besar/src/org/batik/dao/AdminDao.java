/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.batik.dao;

import java.util.List;
import org.batik.model.Admin;
import org.batik.model.Pembeli;
import org.batik.model.Toko;

/**
 *
 * @author Amrianto Saragih
 */
public interface AdminDao {
    public void saveAdmin(Admin admin);
    public void updateAdmin(Admin admin);
    public void deleteAdmin(Admin admin);
    public List<Admin> detAllAdmin();
}
