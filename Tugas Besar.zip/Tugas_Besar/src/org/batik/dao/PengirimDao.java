/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.batik.dao;

import java.util.List;
import org.batik.model.Pengirim;

/**
 *
 * @author Amrianto Saragih
 */
public interface PengirimDao {
    public void savePengirim(Pengirim pengirim);
    public void updatePengirim(Pengirim pengirim);
    public List<Pengirim> getAllPengirim();
    public void deletePengirim(Pengirim pengirim);
}
