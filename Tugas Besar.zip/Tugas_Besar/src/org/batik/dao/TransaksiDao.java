/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.batik.dao;

import java.util.List;
import org.batik.model.Transaksi;

/**
 *
 * @author Amrianto Saragih
 */
public interface TransaksiDao {
    public void saveTransaksi(Transaksi transaksi);
    public List<Transaksi> getAllTransaksi();
    public void deleteTransaksi(Transaksi transaksi);
}
