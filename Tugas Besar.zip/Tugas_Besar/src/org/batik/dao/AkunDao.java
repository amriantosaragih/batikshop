/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.batik.dao;

import java.util.List;
import org.batik.model.Akun;

/**
 *
 * @author Amrianto Saragih
 */
public interface AkunDao {
    public void saveAkun(Akun akun);
    public void updateAkun(Akun akun);
    public List<Akun> getAllAkun();
    public void deleteAkun(Akun akun);  
    public boolean checkUser(String username);
}
